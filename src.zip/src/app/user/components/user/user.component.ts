import { Component, OnInit, Input } from '@angular/core';

//services
import { UserManagerService } from '../../services/user-manager.service';


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {
  name: string;
  porfession: string;
  gender: string;
  knowFor: string;
  @Input() person: any;

  constructor( private userManagerService: UserManagerService ) { }

  ngOnInit(): void {
    this.getPerson();
  }

  getPerson(){
    this.userManagerService
    .getPerson()
    .subscribe((response: any) =>{
      console.log(response)
      const {data} = response;
      const { name, porfession, gender, knowFor }: any = data;
      this.name = `${name.first} ${name.last}`;
      this.porfession = porfession;
      this.gender = gender;
      this.knowFor = knowFor;
    })
  }

}
